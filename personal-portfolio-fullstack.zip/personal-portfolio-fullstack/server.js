require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const connectDB = require("./src/config/db");
const apiRoutes = require("./src/routes");
const { notFound, errorHandler } = require("./src/middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use("/api/contact", rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, message: "Too many messages. Please try again later." }
}));

app.use("/api", apiRoutes);
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ success: true, message: "Portfolio API is running." });
});

app.use(notFound);
app.use(errorHandler);

async function start() {
  if (process.env.MONGODB_URI) {
    try {
      await connectDB();
    } catch (error) {
      console.error("Database connection failed:", error.message);
      process.exit(1);
    }
  } else {
    console.warn("MONGODB_URI is missing. Database-backed endpoints will not work until configured.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Portfolio server listening on port ${PORT}`);
  });
}

start();
