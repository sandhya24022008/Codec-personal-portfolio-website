const $ = (selector) => document.querySelector(selector);
const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
const form = $("#contactForm");
const formStatus = $("#formStatus");
$("#year").textContent = new Date().getFullYear();

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

function safeExternalUrl(url) {
  try {
    const parsed = new URL(url);
    return ["https:", "http:"].includes(parsed.protocol) ? parsed.href : "";
  } catch { return ""; }
}
function makeTag(text) {
  const span = document.createElement("span");
  span.className = "tag";
  span.textContent = text;
  return span;
}
function showLoadError(container, message) {
  container.replaceChildren();
  const p = document.createElement("p");
  p.className = "muted";
  p.textContent = message;
  container.appendChild(p);
}
async function getJSON(path) {
  const response = await fetch(path, { headers: { Accept: "application/json" } });
  const result = await response.json();
  if (!response.ok || !result.success) throw new Error(result.message || "Unable to load data.");
  return result.data;
}
async function loadProfile() {
  const profile = await getJSON("/api/profile");
  if (!profile) throw new Error("No profile data yet. Configure MongoDB and run npm run seed.");
  $("#heroName").textContent = profile.name;
  $("#heroTitle").textContent = profile.title;
  $("#heroIntro").textContent = profile.intro;
  $("#aboutIntro").textContent = profile.intro;
  $("#profileLocation").textContent = profile.location || "";
  $("#footerName").textContent = profile.name;
  $("#monogram").textContent = profile.name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  document.title = `${profile.name} | Portfolio`;

  const educationList = $("#educationList");
  educationList.replaceChildren();
  (profile.education || []).forEach((item) => {
    const card = document.createElement("article");
    card.className = "education-card";
    const title = document.createElement("h3"); title.textContent = item.degree || "Education";
    const institution = document.createElement("p"); institution.textContent = item.institution || "";
    const year = document.createElement("p"); year.textContent = item.year || "";
    const details = document.createElement("p"); details.textContent = item.details || "";
    card.append(title, institution, year, details); educationList.appendChild(card);
  });
}
async function loadSkills() {
  const skills = await getJSON("/api/skills");
  const grid = $("#skillsGrid"); grid.replaceChildren();
  if (!skills.length) return showLoadError(grid, "No skills have been added yet.");
  skills.forEach((skill) => {
    const card = document.createElement("article"); card.className = "skill-card";
    const name = document.createElement("strong"); name.textContent = skill.name;
    const category = document.createElement("span"); category.className = "skill-category"; category.textContent = skill.category || "Other";
    const dots = document.createElement("div"); dots.className = "skill-dots"; dots.setAttribute("aria-label", `Level ${skill.level} out of 5`);
    for (let i = 1; i <= 5; i++) { const dot = document.createElement("span"); if (i <= skill.level) dot.classList.add("filled"); dots.appendChild(dot); }
    card.append(name, category, dots); grid.appendChild(card);
  });
}
async function loadProjects() {
  const projects = await getJSON("/api/projects");
  const grid = $("#projectsGrid"); grid.replaceChildren();
  if (!projects.length) return showLoadError(grid, "No projects have been added yet.");
  projects.forEach((project) => {
    const card = document.createElement("article"); card.className = "project-card";
    const title = document.createElement("h3"); title.textContent = project.title;
    const description = document.createElement("p"); description.textContent = project.description;
    const tags = document.createElement("div"); tags.className = "tags";
    (project.technologies || []).forEach((technology) => tags.appendChild(makeTag(technology)));
    const links = document.createElement("div"); links.className = "project-links";
    const github = safeExternalUrl(project.githubUrl || "");
    const live = safeExternalUrl(project.liveUrl || "");
    if (github) { const a = document.createElement("a"); a.href = github; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = "GitHub ↗"; links.appendChild(a); }
    if (live) { const a = document.createElement("a"); a.href = live; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = "Live demo ↗"; links.appendChild(a); }
    card.append(title, description, tags, links); grid.appendChild(card);
  });
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  formStatus.classList.remove("error");
  formStatus.textContent = "";
  const submitButton = $("#submitButton");
  submitButton.disabled = true;
  submitButton.textContent = "Sending…";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || "Could not send your message.");
    formStatus.textContent = result.message;
    form.reset();
  } catch (error) {
    formStatus.classList.add("error");
    formStatus.textContent = error.message || "Could not send your message. Please try again.";
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Send message";
  }
});

Promise.allSettled([loadProfile(), loadSkills(), loadProjects()]).then((results) => {
  const jobs = [
    [results[0], $("#aboutIntro"), "Profile could not load. Check the database setup."],
    [results[1], $("#skillsGrid"), "Skills could not load. Check the database setup."],
    [results[2], $("#projectsGrid"), "Projects could not load. Check the database setup."]
  ];
  jobs.forEach(([result, container, message]) => {
    if (result.status === "rejected") showLoadError(container, `${message} ${result.reason.message}`);
  });
});
