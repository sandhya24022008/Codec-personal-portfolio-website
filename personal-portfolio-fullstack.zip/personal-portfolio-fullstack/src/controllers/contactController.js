const nodemailer = require("nodemailer");
const ContactMessage = require("../models/ContactMessage");
const { cleanText, isValidEmail } = require("../utils/validation");

async function createContactMessage(req, res, next) {
  try {
    const name = cleanText(req.body.name, 100);
    const email = cleanText(req.body.email, 200).toLowerCase();
    const subject = cleanText(req.body.subject, 150);
    const message = typeof req.body.message === "string" ? req.body.message.trim().slice(0, 3000) : "";

    if (name.length < 2) return res.status(400).json({ success: false, message: "Please enter your name (at least 2 characters)." });
    if (!isValidEmail(email)) return res.status(400).json({ success: false, message: "Please enter a valid email address." });
    if (message.length < 10) return res.status(400).json({ success: false, message: "Message must contain at least 10 characters." });

    const saved = await ContactMessage.create({ name, email, subject, message });

    let emailSent = false;
    const { SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL } = process.env;
    if (SMTP_HOST && SMTP_USER && SMTP_PASS && CONTACT_TO_EMAIL && CONTACT_FROM_EMAIL) {
      try {
        const transporter = nodemailer.createTransport({
          host: SMTP_HOST,
          port: Number(SMTP_PORT || 587),
          secure: String(SMTP_SECURE).toLowerCase() === "true",
          auth: { user: SMTP_USER, pass: SMTP_PASS }
        });
        await transporter.sendMail({
          from: CONTACT_FROM_EMAIL,
          to: CONTACT_TO_EMAIL,
          replyTo: email,
          subject: `Portfolio contact: ${subject || "New message"}`,
          text: `From: ${name} <${email}>\n\n${message}`
        });
        emailSent = true;
      } catch (mailError) {
        console.error("Email notification failed:", mailError.message);
      }
    }

    res.status(201).json({
      success: true,
      message: emailSent
        ? "Your message was saved and an email notification was sent."
        : "Your message was saved. Email notifications are not configured yet.",
      data: { id: saved._id }
    });
  } catch (error) {
    if (error.name === "MongooseError" || error.name === "MongoServerError") {
      return res.status(503).json({ success: false, message: "The database is temporarily unavailable. Please try again later." });
    }
    next(error);
  }
}

module.exports = { createContactMessage };
