const Profile = require("../models/Profile");
const Project = require("../models/Project");
const Skill = require("../models/Skill");

async function getProfile(_req, res, next) {
  try {
    const profile = await Profile.findOne().lean();
    res.json({ success: true, data: profile || null });
  } catch (error) { next(error); }
}

async function getProjects(_req, res, next) {
  try {
    const projects = await Project.find().sort({ featured: -1, createdAt: -1 }).lean();
    res.json({ success: true, data: projects });
  } catch (error) { next(error); }
}

async function getSkills(_req, res, next) {
  try {
    const skills = await Skill.find().sort({ category: 1, name: 1 }).lean();
    res.json({ success: true, data: skills });
  } catch (error) { next(error); }
}

module.exports = { getProfile, getProjects, getSkills };
