function notFound(req, res, _next) {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
}

function errorHandler(error, _req, res, _next) {
  console.error(error);
  res.status(500).json({ success: false, message: "Something went wrong. Please try again later." });
}

module.exports = { notFound, errorHandler };
