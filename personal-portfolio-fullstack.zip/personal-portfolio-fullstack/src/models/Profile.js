const mongoose = require("mongoose");

const profileSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  title: { type: String, required: true, trim: true, maxlength: 150 },
  intro: { type: String, required: true, trim: true, maxlength: 1000 },
  location: { type: String, trim: true, maxlength: 100, default: "" },
  email: { type: String, trim: true, lowercase: true, maxlength: 200, default: "" },
  education: [{ degree: String, institution: String, year: String, details: String }],
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model("Profile", profileSchema);
