const mongoose = require("mongoose");

const contactMessageSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 200 },
  subject: { type: String, trim: true, maxlength: 150, default: "" },
  message: { type: String, required: true, trim: true, maxlength: 3000 },
  status: { type: String, enum: ["new", "read", "replied"], default: "new" }
}, { timestamps: true });

module.exports = mongoose.model("ContactMessage", contactMessageSchema);
