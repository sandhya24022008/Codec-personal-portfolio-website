const mongoose = require("mongoose");

const skillSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 60 },
  category: { type: String, trim: true, maxlength: 60, default: "Other" },
  level: { type: Number, min: 1, max: 5, default: 3 }
}, { timestamps: true });

module.exports = mongoose.model("Skill", skillSchema);
