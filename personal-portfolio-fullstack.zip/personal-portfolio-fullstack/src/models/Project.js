const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, required: true, trim: true, maxlength: 1200 },
  technologies: [{ type: String, trim: true, maxlength: 50 }],
  githubUrl: { type: String, trim: true, maxlength: 500, default: "" },
  liveUrl: { type: String, trim: true, maxlength: 500, default: "" },
  featured: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model("Project", projectSchema);
