const express = require("express");
const { getProfile, getProjects, getSkills } = require("../controllers/portfolioController");
const { createContactMessage } = require("../controllers/contactController");

const router = express.Router();

router.get("/profile", getProfile);
router.get("/projects", getProjects);
router.get("/skills", getSkills);
router.post("/contact", createContactMessage);

module.exports = router;
