# Personal Portfolio Website — Full Stack

A responsive personal portfolio built with HTML, CSS, vanilla JavaScript, Node.js, Express, and MongoDB.

## Features

- Mobile-first responsive portfolio UI
- Profile, education, skills, and project content loaded through REST APIs
- Contact form with server-side validation and MongoDB persistence
- Optional SMTP email notification
- MVC-style separation: models, controllers, routes, middleware, and configuration
- Helmet security headers, JSON body limit, and contact endpoint rate limiting
- Environment variables for secrets

## Requirements

- Node.js 18 or later
- A MongoDB database, such as MongoDB Atlas

## Run locally

1. Clone/download this repository.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Set `MONGODB_URI` in `.env` to your MongoDB connection string. Never commit `.env`.
5. Insert starter content:

   ```bash
   npm run seed
   ```

6. Start the app:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000`.

## REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/profile` | Get profile and education |
| GET | `/api/projects` | Get project list |
| GET | `/api/skills` | Get skills |
| POST | `/api/contact` | Validate and save a contact message |

Example contact request:

```json
{
  "name": "Alex Example",
  "email": "alex@example.com",
  "subject": "Hello",
  "message": "I would like to know more about your project."
}
```

## Email setup

Email is optional until SMTP settings are configured. Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `CONTACT_TO_EMAIL`, and `CONTACT_FROM_EMAIL` in the hosting provider's secret/environment settings. Use an email provider's app password or SMTP credential, not your personal account password.

The contact message is saved to MongoDB before email notification is attempted. Failed email delivery is logged by the server and does not expose secrets to the browser.

## Before publishing

- Replace sample profile, education, skills, and project details with your real information.
- Add actual GitHub/live-demo links only after publishing those projects.
- Configure environment variables in your deployment host.
- Do not commit `.env`, passwords, or API keys.
- Test all APIs and the contact form after deployment.
- Add screenshots of your running website to the repository README.

## Deployment

Deploy the Node.js app to a host that supports Express applications. Set `MONGODB_URI` and any SMTP variables in the host dashboard. The host should use the `npm start` command and provide a `PORT` environment variable. Configure MongoDB Atlas network access and database credentials carefully.

## Architecture

`public/` contains the frontend. `src/models/` contains Mongoose models. `src/controllers/` contains request logic. `src/routes/` defines REST endpoints. `src/config/` contains database connection setup. `src/middleware/` contains shared error handling.

## License

Add a license if you intend to distribute this project publicly.
