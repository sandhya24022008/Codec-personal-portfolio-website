require("dotenv").config();
const connectDB = require("../src/config/db");
const Profile = require("../src/models/Profile");
const Project = require("../src/models/Project");
const Skill = require("../src/models/Skill");

async function seed() {
  await connectDB();

  await Profile.deleteMany({});
  await Project.deleteMany({});
  await Skill.deleteMany({});

  await Profile.create({
    name: "Your Name",
    title: "Student Developer | Aspiring Data Analyst",
    intro: "I am an engineering student interested in web development, data, and building useful digital solutions. Replace this introduction with your own story.",
    location: "Your City, India",
    email: "your.email@example.com",
    education: [{
      degree: "B.Tech — Your Department",
      institution: "Your College",
      year: "Expected graduation: 2029",
      details: "Add your relevant coursework or achievements."
    }]
  });

  await Project.insertMany([
    {
      title: "Small Canteen Food Waste Prediction System",
      description: "A student project concept that uses past food preparation and leftover data to help estimate future canteen food requirements. Update this description to match the version you actually build.",
      technologies: ["Python", "Data Analysis", "Visualization"],
      githubUrl: "",
      liveUrl: "",
      featured: true
    },
    {
      title: "Data Redundancy Removal System",
      description: "A project focused on identifying and reducing duplicate data. Replace this with the actual features and implementation details of your project.",
      technologies: ["Python"],
      githubUrl: "",
      liveUrl: "",
      featured: false
    }
  ]);

  await Skill.insertMany([
    { name: "Python", category: "Programming", level: 3 },
    { name: "SQL", category: "Database", level: 3 },
    { name: "HTML", category: "Web Development", level: 3 },
    { name: "CSS", category: "Web Development", level: 3 },
    { name: "JavaScript", category: "Web Development", level: 2 },
    { name: "MongoDB", category: "Database", level: 1 },
    { name: "Node.js", category: "Backend", level: 1 }
  ]);

  console.log("Sample portfolio data inserted. Edit it to match your actual details.");
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
