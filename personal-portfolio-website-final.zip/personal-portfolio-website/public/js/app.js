const $ = (selector) => document.querySelector(selector);
$("#year").textContent = new Date().getFullYear();

async function loadPortfolio() {
  try {
    const [profileResponse, skillsResponse, projectsResponse] = await Promise.all([
      fetch("/api/profile"), fetch("/api/skills"), fetch("/api/projects")
    ]);
    if (profileResponse.ok) {
      const profile = await profileResponse.json();
      $("#hero-name").textContent = profile.name || "Your Name";
      $("#hero-headline").textContent = profile.headline || "Aspiring Data Analyst | AI & Data Science Student";
      $("#about-text").textContent = profile.about || "";
      $("#location").textContent = profile.location || "India";
      if (profile.email) {
        $("#email-link").textContent = `${profile.email} ↗`;
        $("#email-link").href = `mailto:${profile.email}`;
      }
      document.title = `Portfolio | ${profile.name || "Your Name"}`;
    }
    if (skillsResponse.ok) renderSkills(await skillsResponse.json());
    if (projectsResponse.ok) renderProjects(await projectsResponse.json());
  } catch (error) {
    console.info("Using built-in demo content.", error.message);
  }
}
function renderSkills(skills) {
  if (!Array.isArray(skills) || !skills.length) return;
  $("#skills-grid").replaceChildren(...skills.map(skill => {
    const card = document.createElement("div"); card.className = "skill-card";
    const name = document.createElement("span"); name.textContent = skill.name;
    const track = document.createElement("div"); track.className = "skill-track";
    const fill = document.createElement("i"); fill.style.width = `${Math.max(0, Math.min(100, Number(skill.level) || 0))}%`;
    track.append(fill); card.append(name, track); return card;
  }));
}
function renderProjects(projects) {
  if (!Array.isArray(projects) || !projects.length) return;
  $("#projects-grid").replaceChildren(...projects.map((project, index) => {
    const card = document.createElement("article"); card.className = "project-card";
    const number = document.createElement("div"); number.className = "project-number"; number.textContent = `PROJECT / ${String(index + 1).padStart(2, "0")}`;
    const title = document.createElement("h3"); title.textContent = project.title || "Project";
    const description = document.createElement("p"); description.textContent = project.description || "";
    const tags = document.createElement("div"); tags.className = "tags";
    (project.technologies || []).forEach(technology => { const tag = document.createElement("span"); tag.textContent = technology; tags.append(tag); });
    card.append(number, title, description, tags);
    if (project.githubUrl) { const link = document.createElement("a"); link.className = "text-link"; link.href = project.githubUrl; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = "View code ↗"; card.append(link); }
    return card;
  }));
}
$("#contact-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const status = $("#form-status");
  const submit = event.currentTarget.querySelector("button");
  status.textContent = "Sending…"; submit.disabled = true;
  try {
    const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget))) });
    const result = await response.json();
    status.textContent = result.message || (response.ok ? "Message sent." : "Could not send message.");
    if (response.ok) event.currentTarget.reset();
  } catch {
    status.textContent = "Could not connect. Please try again later.";
  } finally { submit.disabled = false; }
});
loadPortfolio();