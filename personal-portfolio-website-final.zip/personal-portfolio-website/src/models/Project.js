const mongoose = require("mongoose");
const projectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  technologies: [String],
  githubUrl: String,
  liveUrl: String,
  featured: { type: Boolean, default: false }
}, { timestamps: true });
module.exports = mongoose.models.Project || mongoose.model("Project", projectSchema);