const mongoose = require("mongoose");
const profileSchema = new mongoose.Schema({
  name: { type: String, required: true },
  headline: String,
  about: String,
  email: String,
  location: String,
  links: { github: String, linkedin: String }
}, { timestamps: true });
module.exports = mongoose.models.Profile || mongoose.model("Profile", profileSchema);