const mongoose = require("mongoose");
const skillSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, default: "General" },
  level: { type: Number, min: 0, max: 100, default: 70 }
}, { timestamps: true });
module.exports = mongoose.models.Skill || mongoose.model("Skill", skillSchema);