const Skill = require("../models/Skill");
exports.getSkills = async (_req, res) => {
  try {
    const skills = await Skill.find().sort({ category: 1, name: 1 }).lean();
    res.json(skills.length ? skills : [
      { name: "Python", category: "Programming", level: 75 },
      { name: "SQL", category: "Data", level: 70 },
      { name: "Excel", category: "Data", level: 75 },
      { name: "HTML & CSS", category: "Web", level: 65 },
      { name: "JavaScript", category: "Web", level: 55 },
      { name: "Data Analysis", category: "Data", level: 65 }
    ]);
  } catch (error) { res.status(500).json({ message: "Could not load skills" }); }
};