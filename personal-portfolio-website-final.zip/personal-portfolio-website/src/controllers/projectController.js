const Project = require("../models/Project");
exports.getProjects = async (_req, res) => {
  try {
    const projects = await Project.find().sort({ createdAt: -1 }).lean();
    res.json(projects.length ? projects : [
      { title: "Data Redundancy Removal System", description: "A Python project concept focused on identifying and removing duplicate data.", technologies: ["Python"], githubUrl: "", featured: true },
      { title: "Detection Project", description: "A practical project demonstrating detection logic and clear results.", technologies: ["Python"], githubUrl: "", featured: true },
      { title: "Personal Portfolio Website", description: "A responsive portfolio for presenting skills, projects, and contact details.", technologies: ["HTML", "CSS", "JavaScript", "Node.js"], githubUrl: "", featured: true }
    ]);
  } catch (error) { res.status(500).json({ message: "Could not load projects" }); }
};