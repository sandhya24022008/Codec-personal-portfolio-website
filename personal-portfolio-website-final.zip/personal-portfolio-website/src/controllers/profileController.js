const Profile = require("../models/Profile");
exports.getProfile = async (_req, res) => {
  try {
    const profile = await Profile.findOne().lean();
    res.json(profile || {
      name: "Your Name",
      headline: "Aspiring Data Analyst | AI & Data Science Student",
      about: "I enjoy turning data into useful insights and building practical technology projects.",
      email: "hello@example.com",
      location: "India",
      links: { github: "", linkedin: "" }
    });
  } catch (error) { res.status(500).json({ message: "Could not load profile" }); }
};