const ContactMessage = require("../models/ContactMessage");
exports.createContact = async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ message: "Please fill in all fields." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Enter a valid email address." });
  try {
    if (ContactMessage.db.readyState !== 1) return res.status(503).json({ message: "Contact storage is not configured yet. Please email me directly." });
    await ContactMessage.create({ name, email, message });
    res.status(201).json({ message: "Thanks! Your message has been saved." });
  } catch (error) { res.status(500).json({ message: "Could not send message. Please try again." }); }
};