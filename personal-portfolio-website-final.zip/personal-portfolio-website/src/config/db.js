const mongoose = require("mongoose");

async function connectDB() {
  if (!process.env.MONGODB_URI) {
    console.warn("MONGODB_URI is not set. Starting without database; demo frontend remains available.");
    return;
  }
  try {
    await mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 4000 });
    console.log("MongoDB connected");
  } catch (error) {
    console.warn("MongoDB connection unavailable:", error.message);
  }
}
module.exports = connectDB;