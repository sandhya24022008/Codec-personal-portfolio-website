require("dotenv").config();
const express = require("express");
const path = require("path");
const connectDB = require("./src/config/db");
const projectRoutes = require("./src/routes/projectRoutes");
const profileRoutes = require("./src/routes/profileRoutes");
const skillRoutes = require("./src/routes/skillRoutes");
const contactRoutes = require("./src/routes/contactRoutes");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => res.json({ status: "ok", message: "Portfolio API is running" }));
app.use("/api/projects", projectRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/skills", skillRoutes);
app.use("/api/contact", contactRoutes);

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const PORT = process.env.PORT || 3000;
connectDB().finally(() => {
  app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
});